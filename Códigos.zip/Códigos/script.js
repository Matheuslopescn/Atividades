window.alert("Meu primeiro texto")
window.confirm("Confirme clicando em OK")
//window.prompt("escreva o seu nome? ")

var nome= window.prompt("Qual é seu nome?")
alert("É um prazer te conhecer " + nome)